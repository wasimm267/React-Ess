
import React from "react";
import Header from "Header"
import Foot from "Foot"

class App extends React.Component {
  render() {
    const { name } = this.props;
    return (
      <>
        <h1>
          Hello {name}
        </h1>
        <Header/>
          <Foot/>
        
        
      </>
    );
  }
}

export default App;
