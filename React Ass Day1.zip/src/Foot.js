function Foot(){
  return( 
    <h1> My Name Is Wasim </h1>
    
    )
}
export default Foot;
